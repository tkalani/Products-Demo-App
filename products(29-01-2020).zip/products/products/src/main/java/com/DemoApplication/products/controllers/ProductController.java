package com.DemoApplication.products.controllers;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.DemoApplication.products.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.DemoApplication.products.models.Product;
import com.DemoApplication.products.services.ProductService;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins= "http://localhost:4200")
public class ProductController {
	
	private ProductService productService;

	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	@GetMapping({"", "/"})
	public ResponseEntity<Set<Product>> getAllProducts(){
		Set<Product> products = productService.findAll()
				.stream()
				.map(item -> {
					Product newProd = new Product();
					newProd.setId(item.getId());
					newProd.setName(item.getName());
					newProd.setProductType(item.getProductType());

					User tempUser = new User();
					tempUser.setId(item.getUser().getId());
					tempUser.setName(item.getUser().getName());
					tempUser.setEmail(item.getUser().getEmail());
					newProd.setUser(tempUser);
					return newProd;
				})
				.collect(Collectors.toSet());
		return new ResponseEntity<Set<Product>>(products, HttpStatus.OK);
	}
	
	// Working - Get Product By Id --
	@GetMapping("/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable("id") Long id){
		Optional<Product> foundProduct = productService.findById(id);
		if(foundProduct.isPresent()) {
			Product newProd = new Product();
			newProd.setId(foundProduct.get().getId());
			newProd.setName(foundProduct.get().getName());
			newProd.setProductType(foundProduct.get().getProductType());

			User tempUser = new User();
			tempUser.setId(foundProduct.get().getUser().getId());
			tempUser.setName(foundProduct.get().getUser().getName());
			tempUser.setEmail(foundProduct.get().getUser().getEmail());
			newProd.setUser(tempUser);

			return new ResponseEntity<Product>(newProd, HttpStatus.OK);
		} else {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Product Not Found");
		}
	}
	/* OUTPUT:
		{
			"id": 16,
			"name": "Bugatti",
			"productType": {
				"id": 4,
				"name": "Car"
			},
			"user": {
				"id": 19,
				"name": "junaid",
				"email": "junaid@email",
				"password": null,
				"products": []
			}
		}
	*/
	
	// Working - Add new Product --
	/* INPUT:
	{
		"name": "Porsche",
		"productType": {
			"id": 4
		},
		"user": {
			"id": 19
		}
	}
	*/
	@PostMapping({"", "/"})
	public ResponseEntity<Product> create(@RequestBody Product product){
		Product newCreatedProduct = productService.save(product);
		return new ResponseEntity<Product>(newCreatedProduct, HttpStatus.OK);
	}
	/* OUTPUT
	{
		"id": 20,
		"name": "Porsche",
		"productType": {
			"id": 4,
			"name": "Car"
		},
		"user": {
			"id": 19,
			"name": "junaid",
			"email": "junaid@email",
			"password": null,
			"products": []
		}
	}
	*/
	
	// Working - Delete Product by ID --
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteProductById(@PathVariable Long id){
		productService.deleteById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
