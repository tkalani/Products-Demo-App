package com.DemoApplication.products.controllers;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.DemoApplication.products.models.Product;
import com.DemoApplication.products.models.User;
import com.DemoApplication.products.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.DemoApplication.products.models.ProductType;
import com.DemoApplication.products.services.ProductTypeService;

@RestController
@RequestMapping("/api/product-types")
@CrossOrigin(origins= "http://localhost:4200")
public class ProductTypeController {

	private ProductTypeService productTypeService;
	private ProductService productService;
	
	@Autowired
	public void setProductTypeService(ProductTypeService productTypeService, ProductService productService) {
		this.productTypeService = productTypeService;
		this.productService = productService;
	}
	
	// Working - Get all product-types --
	@GetMapping({"", "/"})
	public ResponseEntity<Set<ProductType>> getAllProductTypes(){
		Set<ProductType> productTypes = productTypeService.findAll();
		return new ResponseEntity<Set<ProductType>>(productTypes, HttpStatus.OK);
	}

	// Working - Get all products of a particular product type --
	@GetMapping("/{type_id}/p")
	public ResponseEntity<Set<Product>> getAllProductsOfProductType(@PathVariable("type_id") Long type_id){
		Set<Product> products = productService.findAll()
				.stream()
				.filter(p -> p.getProductType().getId()==type_id)
				.map(item -> {
					Product newProd = new Product();
					newProd.setId(item.getId());
					newProd.setName(item.getName());
					newProd.setProductType(item.getProductType());

					User tempUser = new User();
					tempUser.setId(item.getUser().getId());
					tempUser.setName(item.getUser().getName());
					tempUser.setEmail(item.getUser().getEmail());
					newProd.setUser(tempUser);
					return newProd;
				})
				.collect(Collectors.toSet());
		return new ResponseEntity<Set<Product>>(products, HttpStatus.OK);
	}
	
	// Working - Get a product-type by ID --
	@GetMapping("/{id}")
	public ResponseEntity<ProductType> getProductTypeById(@PathVariable("id") Long id){
		Optional<ProductType> foundProductType = productTypeService.findById(id);
		if(foundProductType.isPresent()) {
			return new ResponseEntity<ProductType>(foundProductType.get(), HttpStatus.OK);
		} else {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Product Type Not Found");
		}
	}
	
	// Working - Create new Product-Type --
	@PostMapping({"", "/"})
	public ResponseEntity<ProductType> create(@RequestBody ProductType productType){
		ProductType newCreatedProductType = productTypeService.save(productType);
		return new ResponseEntity<ProductType>(newCreatedProductType, HttpStatus.OK);
	}
	
	// Working - Delete Product-Type by object --
	@DeleteMapping("/")
	public ResponseEntity<Void> deleteProductType(@RequestBody ProductType productType){
		productTypeService.delete(productType);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	// Working - Delete Product-Type By ID  -> Works only if no user has a product of this type.
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteProductTypeById(@PathVariable Long id){
		productTypeService.deleteById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	// Working - Update Product-Type --
	@PutMapping({"", "/"})
	public ResponseEntity<ProductType> updateProductType(@RequestBody ProductType productType){
		ProductType updatedProductType = productTypeService.save(productType);
		return new ResponseEntity<ProductType>(updatedProductType, HttpStatus.OK);
	}
}
