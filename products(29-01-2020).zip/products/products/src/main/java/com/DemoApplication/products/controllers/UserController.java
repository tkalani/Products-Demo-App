package com.DemoApplication.products.controllers;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.DemoApplication.products.models.Product;
import com.DemoApplication.products.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.DemoApplication.products.models.User;
import com.DemoApplication.products.services.UserService;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins= "http://localhost:4200")
public class UserController {
	
	private UserService userService;
	private ProductService productService;
	
	@Autowired
	public void setUserService(UserService userService, ProductService productService) {
		this.userService = userService;
		this.productService = productService;
	}
	
	// Working - Get all users --
	@GetMapping({"", "/"})
	public ResponseEntity<Set<User>> getAllUsers(){
		Set<User> users = userService.findAll()
									.stream()
									.map(u -> {
										User outUser = new User();
										outUser.setId(u.getId());
										outUser.setName(u.getName());
										outUser.setEmail(u.getEmail());
										outUser.setPassword(u.getPassword());
										return outUser;
									})
									.collect(Collectors.toSet());
		return new ResponseEntity<Set<User>>(users, HttpStatus.OK);
	}

	// Working - Get all products of a particular user --
	@GetMapping("/{user_id}/p")
	public ResponseEntity<Set<Product>> getAllProductsOfUser(@PathVariable("user_id") Long user_id){
		Set<Product> products = productService.findAll()
				.stream()
				.filter(p -> p.getUser().getId()==user_id)
				.map(item -> {
					Product newProd = new Product();
					newProd.setId(item.getId());
					newProd.setName(item.getName());
					newProd.setProductType(item.getProductType());
					return newProd;
				})
				.collect(Collectors.toSet());
		return new ResponseEntity<Set<Product>>(products, HttpStatus.OK);
	}
	
	// Working - Get particular user details --
	@GetMapping("/{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id") Long id){
		Optional<User> foundUser = userService.findById(id);
		if(foundUser.isPresent()) {
			User outUser = new User();
			outUser.setId(foundUser.get().getId());
			outUser.setName(foundUser.get().getName());
			outUser.setEmail(foundUser.get().getEmail());
			outUser.setPassword(foundUser.get().getPassword());
			return new ResponseEntity<User>(outUser, HttpStatus.OK);
		} else {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User Not Found");
		}
	}

	@PostMapping({"", "/"})
	public ResponseEntity<User> createUser(@RequestBody User user){
		User createdUser = userService.save(user);
		return new ResponseEntity<User>(createdUser, HttpStatus.OK);
	}
	
	// Working - Delete a particular user by id --
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUserById(@PathVariable Long id){
		userService.deleteById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
}
