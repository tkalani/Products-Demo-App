package com.DemoApplication.products.services;

import com.DemoApplication.products.models.Product;

public interface ProductService extends CrudService<Product, Long> {

}
