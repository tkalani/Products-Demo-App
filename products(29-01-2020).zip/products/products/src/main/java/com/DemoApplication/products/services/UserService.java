package com.DemoApplication.products.services;

import com.DemoApplication.products.models.User;

public interface UserService extends CrudService<User, Long> {

}
