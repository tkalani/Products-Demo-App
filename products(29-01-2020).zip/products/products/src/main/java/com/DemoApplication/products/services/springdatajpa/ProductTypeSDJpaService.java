package com.DemoApplication.products.services.springdatajpa;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DemoApplication.products.models.ProductType;
import com.DemoApplication.products.repositories.ProductTypeRepository;
import com.DemoApplication.products.services.ProductTypeService;

@Service
public class ProductTypeSDJpaService implements ProductTypeService {
	
	@Autowired
	private final ProductTypeRepository productTypeRepository;

	public ProductTypeSDJpaService(ProductTypeRepository productTypeRepository) {
		this.productTypeRepository = productTypeRepository;
	}
	
	@Override
	public Set<ProductType> findAll() {
		Set<ProductType> productTypes = new HashSet<>();
		productTypeRepository.findAll().forEach(productTypes::add);
		return productTypes;
	}
	
	@Override
    public Optional<ProductType> findById(Long aLong) {
        return productTypeRepository.findById(aLong);
    }

    @Override
    public ProductType save(ProductType object) {
        return productTypeRepository.save(object);
    }

    @Override
    public void delete(ProductType object) {
    	productTypeRepository.delete(object);
    }

    @Override
    public void deleteById(Long aLong) {
    	productTypeRepository.deleteById(aLong);
    }
    
    @Override
    public ProductType update(ProductType object){
    	return productTypeRepository.save(object);
    }

}
