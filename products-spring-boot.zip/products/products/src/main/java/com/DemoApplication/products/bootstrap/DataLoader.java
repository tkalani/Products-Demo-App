package com.DemoApplication.products.bootstrap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.DemoApplication.products.models.Product;
import com.DemoApplication.products.models.ProductType;
import com.DemoApplication.products.models.User;
import com.DemoApplication.products.repositories.ProductRepository;
import com.DemoApplication.products.repositories.ProductTypeRepository;
import com.DemoApplication.products.repositories.UserRepository;

@Component
public class DataLoader implements ApplicationRunner {
	
	private ProductTypeRepository productTypeRepository;
	private ProductRepository productRepository;
	private UserRepository userRepository;
	
	 @Autowired
	 public DataLoader(ProductTypeRepository productTypeRepository, ProductRepository productRepository, UserRepository userRepository) {
	        this.productTypeRepository = productTypeRepository;
	        this.productRepository = productRepository;
	        this.userRepository = userRepository;
	    }
	 
	@Override
    public void run(ApplicationArguments args) throws Exception {
		loadData();
    }
	
	private void loadData(){
		// Creating and Saving Product Types ----------------------------------
		ProductType food = new ProductType();
		food.setName("Food");
        productTypeRepository.save(food);
        
        ProductType computer = new ProductType();
        computer.setName("Computer");
        productTypeRepository.save(computer);
        
        ProductType mobile = new ProductType();
        mobile.setName("Mobile");
        productTypeRepository.save(mobile);
        
        ProductType car = new ProductType();
        car.setName("Car");
        productTypeRepository.save(car);
        
//      Creating Products without users --------------------------------
        Product burger = new Product();
        burger.setName("Burger");
        burger.setProductType(food);
        productRepository.save(burger);
        
        Product maggi = new Product();
        maggi.setName("Maggi");
        maggi.setProductType(food);
        productRepository.save(maggi);
        
        Product pizza = new Product();
        pizza.setName("Pizza");
        pizza.setProductType(food);
        productRepository.save(pizza);
        // ------------------------
        Product apple = new Product();
        apple.setName("Apple");
        apple.setProductType(computer);
        productRepository.save(apple);
        
        Product dell = new Product();
        dell.setName("Dell");
        dell.setProductType(computer);
        productRepository.save(dell);
        
        Product hp = new Product();
        hp.setName("HP");
        hp.setProductType(computer);
        productRepository.save(hp);
        //----------------------
        Product moto = new Product();
        moto.setName("Moto");
        moto.setProductType(mobile);
        productRepository.save(moto);
        
        Product nokia = new Product();
        nokia.setName("Nokia");
        nokia.setProductType(mobile);
        productRepository.save(nokia);
        
        Product oneplus = new Product();
        oneplus.setName("OnePlus");
        oneplus.setProductType(mobile);
        productRepository.save(oneplus);
        // ----------------------
        Product audi = new Product();
        audi.setName("Audi");
        audi.setProductType(car);
        productRepository.save(audi);
        
        Product mercedes = new Product();
        mercedes.setName("Mercedes");
        mercedes.setProductType(car);
        productRepository.save(mercedes);
        
        Product bugatti = new Product();
        bugatti.setName("Bugatti");
        bugatti.setProductType(car);
        productRepository.save(bugatti);
        
        // Creating users ---------------------------------------------
        User tanmay = new User();
        tanmay.setName("tanmay");
        tanmay.setEmail("tanmay@email");
        tanmay.setPassword("tanmay");
        userRepository.save(tanmay);
        
        burger.setUser(tanmay);
        productRepository.save(burger);
        apple.setUser(tanmay);
        productRepository.save(apple);
        moto.setUser(tanmay);
        productRepository.save(moto);
        audi.setUser(tanmay);
        productRepository.save(audi);
        
        User anurag = new User();
        anurag.setName("anurag");
        anurag.setEmail("anurag@email");
        anurag.setPassword("anurag");
        userRepository.save(anurag);
        
        maggi.setUser(anurag);
        productRepository.save(maggi);
        dell.setUser(anurag);
        productRepository.save(dell);
        nokia.setUser(anurag);
        productRepository.save(nokia);
        mercedes.setUser(anurag);
        productRepository.save(mercedes);
        
        User junaid = new User();
        junaid.setName("junaid");
        junaid.setEmail("junaid@email");
        junaid.setPassword("junaid");
        userRepository.save(junaid);
        
        pizza.setUser(junaid);
        productRepository.save(pizza);
        hp.setUser(junaid);
        productRepository.save(hp);
        oneplus.setUser(junaid);
        productRepository.save(oneplus);
        bugatti.setUser(junaid);
        productRepository.save(bugatti);
        
	}

}
