package com.DemoApplication.products.controllers;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.DemoApplication.products.models.Product;
import com.DemoApplication.products.services.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	private ProductService productService;

	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	// Working - Get all products of a particular user --
	@GetMapping("/user/{user_id}")
	public ResponseEntity<Set<Product>> getAllProducts(@PathVariable("user_id") Long user_id){
		Set<Product> products = productService.findAll()
											.stream()
											.filter(p -> p.getUser().getId()==user_id)
											.map(item -> {
												Product newProd = new Product();
												newProd.setId(item.getId());
												newProd.setName(item.getName());
												newProd.setProductType(item.getProductType());
												return newProd;
											})
											.collect(Collectors.toSet());
		return new ResponseEntity<Set<Product>>(products, HttpStatus.OK);
	}
	
	// Working - Get Product By Id --
	@GetMapping("/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable("id") Long id){
		Optional<Product> foundProduct = productService.findById(id);
		if(foundProduct.isPresent()) {
			Product newProd = new Product();
			newProd.setId(foundProduct.get().getId());
			newProd.setName(foundProduct.get().getName());
			newProd.setProductType(foundProduct.get().getProductType());
			return new ResponseEntity<Product>(newProd, HttpStatus.OK);
		} else {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Product Not Found");
		}
	}
	
	// Working - Add new Product for a particular user --
	@PostMapping("/{user_id}")
	public ResponseEntity<Product> create(@RequestBody Product product){
		Product newCreatedProduct = productService.save(product);
		return new ResponseEntity<Product>(newCreatedProduct, HttpStatus.OK);
	}
	
	// Working - Delete Product by ID --
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteProductById(@PathVariable Long id){
		productService.deleteById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
