package com.DemoApplication.products.controllers;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.DemoApplication.products.models.User;
import com.DemoApplication.products.services.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	
	private UserService userService;
	
	@Autowired
	public void setProductTypeService(UserService userService) {
		this.userService = userService;
	}
	
	// Working - Get all users --
	@GetMapping({"", "/"})
	public ResponseEntity<Set<User>> getAllUsers(){
		Set<User> users = userService.findAll()
									.stream()
									.map(u -> {
										User outUser = new User();
										outUser.setId(u.getId());
										outUser.setName(u.getName());
										outUser.setEmail(u.getEmail());
										outUser.setPassword(u.getPassword());
										return outUser;
									})
									.collect(Collectors.toSet());
		return new ResponseEntity<Set<User>>(users, HttpStatus.OK);
	}
	
	// Working - Get particular user details --
	@GetMapping("/{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id") Long id){
		Optional<User> foundUser = userService.findById(id);
		if(foundUser.isPresent()) {
			User outUser = new User();
			outUser.setId(foundUser.get().getId());
			outUser.setName(foundUser.get().getName());
			outUser.setEmail(foundUser.get().getEmail());
			outUser.setPassword(foundUser.get().getPassword());
			return new ResponseEntity<User>(outUser, HttpStatus.OK);
		} else {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User Not Found");
		}
	}
	
	// Working - Delete a particular user by id --
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUserById(@PathVariable Long id){
		userService.deleteById(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
}
