package com.DemoApplication.products.repositories;

import org.springframework.data.repository.CrudRepository;

import com.DemoApplication.products.models.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {

}
