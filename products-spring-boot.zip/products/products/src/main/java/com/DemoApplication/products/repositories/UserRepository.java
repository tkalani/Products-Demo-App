package com.DemoApplication.products.repositories;

import org.springframework.data.repository.CrudRepository;

import com.DemoApplication.products.models.User;

public interface UserRepository extends CrudRepository<User, Long> {
	
}
