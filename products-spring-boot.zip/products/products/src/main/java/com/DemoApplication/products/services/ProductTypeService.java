package com.DemoApplication.products.services;

import com.DemoApplication.products.models.ProductType;

public interface ProductTypeService extends CrudService<ProductType, Long> {

}
