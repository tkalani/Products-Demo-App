package com.DemoApplication.products.services.springdatajpa;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DemoApplication.products.models.Product;
import com.DemoApplication.products.repositories.ProductRepository;
import com.DemoApplication.products.services.ProductService;

@Service
public class ProductSDJpaService implements ProductService {
	
	@Autowired
	private final ProductRepository productRepository;

    public ProductSDJpaService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public Set<Product> findAll() {
        Set<Product> products = new HashSet<>();
        productRepository.findAll().forEach(products::add);
        return products;
    }

    @Override
    public Optional<Product> findById(Long aLong) {
        return productRepository.findById(aLong);
    }

    @Override
    public Product save(Product object) {
        return productRepository.save(object);
    }

    @Override
    public void delete(Product object) {
    	productRepository.delete(object);
    }

    @Override
    public void deleteById(Long aLong) {
    	productRepository.deleteById(aLong);
    }
    
    @Override
    public Product update(Product object){
    	return productRepository.save(object);
    }

}
