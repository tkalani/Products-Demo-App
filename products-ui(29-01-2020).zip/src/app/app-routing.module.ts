import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './home/welcome/welcome.component';
import { PageNotFoundComponent } from './common/page-not-found/page-not-found.component';

const routes: Routes = [
  { path: 'welcome', component: WelcomeComponent },
  { path: 'products', 
    loadChildren: () => import('./products/products.module').then(m => m.ProductModule)  
  },
  { path: 'users', 
    loadChildren: () => import('./user/user.module').then(m => m.UserModule)  
  },
  {
    path: 'product-types',
    loadChildren: () => import('./product-type/product-type.module').then(m => m.ProductTypeModule) 
  },
  { path: '404', component: PageNotFoundComponent },
  { path: '', redirectTo: 'welcome', pathMatch: 'full' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
