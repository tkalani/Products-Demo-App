import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome/welcome.component';
import { ModalTriggerDirective } from './common/modalTrigger.directive';
import { JQ_TOKEN } from './common/jQuery.service';
import { SimpleModalComponent } from './common/simpleModal.component';
import { PageNotFoundComponent } from './common/page-not-found/page-not-found.component';

let jQuery = window['$'];

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    ModalTriggerDirective,
    SimpleModalComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [
    {provide: JQ_TOKEN, useValue: jQuery }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
