import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome/welcome.component';
import { ModalTriggerDirective } from './common/modalTrigger.directive';
import { JQ_TOKEN } from './common/jQuery.service';
import { SimpleModalComponent } from './common/simpleModal.component';
import { PageNotFoundComponent } from './common/page-not-found/page-not-found.component';
import { AddHeaderInterceptor } from './common/add-header.interceptor';
import { LogResponseInterceptor } from './common/log-response.interceptor';
import { CacheInterceptor } from './common/cache.interceptor';

let jQuery = window['$'];

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    ModalTriggerDirective,
    SimpleModalComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [
    {provide: JQ_TOKEN, useValue: jQuery },
    { provide: HTTP_INTERCEPTORS, useClass: AddHeaderInterceptor, multi: true},
    { provide: HTTP_INTERCEPTORS, useClass: LogResponseInterceptor, multi: true},
    { provide: HTTP_INTERCEPTORS, useClass: CacheInterceptor, multi: true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
