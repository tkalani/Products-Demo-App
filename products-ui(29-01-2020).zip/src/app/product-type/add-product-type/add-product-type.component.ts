import { Component, OnInit, AfterViewInit, OnDestroy, ViewChildren, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormControlName, Validators } from '@angular/forms';
import { ProductType } from '../product-type';
import { ProductTypeService } from '../product-type.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product-type',
  templateUrl: './add-product-type.component.html',
  styleUrls: ['./add-product-type.component.css']
})
export class AddProductTypeComponent implements OnInit {
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];
  newProductTypeForm: FormGroup;

  constructor(private fb: FormBuilder, 
              private productTypeService: ProductTypeService,
              private router: Router) { }

  ngOnInit() {
    this.newProductTypeForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]]
    });
  }

  saveProductType(formValues): void {
    if(this.newProductTypeForm.valid){
      let productType: ProductType = formValues;
      this.productTypeService.createProductType(productType).subscribe();
      this.router.navigate(['/product-types']);
    }
  }

}
