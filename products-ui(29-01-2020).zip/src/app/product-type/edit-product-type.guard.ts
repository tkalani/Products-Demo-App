import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';
import { EditProductTypeComponent } from './edit-product-type/edit-product-type.component';

@Injectable({
  providedIn: 'root'
})
export class EditProductTypeGuard implements CanDeactivate<EditProductTypeComponent> {
  canDeactivate(component: EditProductTypeComponent,
                currentRoute: ActivatedRouteSnapshot,
                currentState: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    
      if(component.isDirty){
        return confirm("Changes are not saved. Do you want to leave without saving?");
      }
      return true;
  }
  
}
