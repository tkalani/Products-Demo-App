import { Component, OnInit, AfterViewInit, OnDestroy, ViewChildren, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormControlName, Validators } from '@angular/forms';
import { ProductType } from '../product-type';
import { ProductTypeService } from '../product-type.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-product-type',
  templateUrl: './edit-product-type.component.html',
  styleUrls: ['./edit-product-type.component.css']
})
export class EditProductTypeComponent implements OnInit {
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];
  newProductTypeForm: FormGroup;
  // productType: ProductType;

  private currentProductType: ProductType;
  private orgProductType: ProductType;

  get productType(): ProductType {
    return this.currentProductType;
  }
  set productType(value: ProductType) {
    this.currentProductType = value;
  }

  get isDirty(): boolean {
    return JSON.stringify(this.orgProductType)!==JSON.stringify(this.currentProductType);
  }

  reset(): void {
    this.currentProductType = null;
    this.orgProductType = null;
  }

  constructor(private fb: FormBuilder,
    private productTypeService: ProductTypeService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.newProductTypeForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]]
    });

    this.route.paramMap.subscribe(
      data => {
        this.productTypeService.getProductTypeByID(+data.get('id')).subscribe({
          next: productType => {
            this.productType = productType;
            // this.orgProductType = { ...productType };
            this.initializeForm(productType);
          }
        });
      }
    );
  }

  initializeForm(productType: ProductType): void {
    this.newProductTypeForm = this.fb.group({
      name: [productType.name, [Validators.required, Validators.minLength(3)]]
    });
  }

  saveProductType(formValues): void {
    if (this.newProductTypeForm.valid) {
      formValues.id = this.productType.id;
      let productType: ProductType = formValues;
      this.productTypeService.updateProductType(productType).subscribe(
        data => {
          this.reset();
          this.router.navigate(['/product-types']);
        },
        error => {
          console.log('Product Type not edited.');
        }
      );
    }
  }

}
