import { TestBed, async, inject } from '@angular/core/testing';

import { ProductExistGuard } from './product-exist.guard';

describe('ProductExistGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProductExistGuard]
    });
  });

  it('should ...', inject([ProductExistGuard], (guard: ProductExistGuard) => {
    expect(guard).toBeTruthy();
  }));
});
