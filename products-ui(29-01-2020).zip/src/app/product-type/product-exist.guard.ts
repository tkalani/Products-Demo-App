import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router, ActivatedRoute } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { ProductTypeService } from './product-type.service';

@Injectable({
  providedIn: 'root'
})
export class ProductExistGuard implements CanActivate {

  private productTypeExists: boolean = false;
  constructor(private productTypeService: ProductTypeService,
    private router: Router) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    var productTypeExists = this.productTypeService.getProductTypeByID(+next.params['id']);
    var subject = new Subject<boolean>();
    productTypeExists.subscribe(
      res => {
        if (!res) {
          console.log("Type doesn't exist");
          this.router.navigate(['/404']);
        }
        subject.next(!!res);
      },
      error => {
        this.router.navigate(['/404']);
        return false;
      });
    return subject.asObservable();
  }

}
