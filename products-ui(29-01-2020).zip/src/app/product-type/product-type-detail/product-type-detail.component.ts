import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-type-detail',
  templateUrl: './product-type-detail.component.html',
  styleUrls: ['./product-type-detail.component.css']
})
export class ProductTypeDetailComponent implements OnInit {
  orgProducts: any[] = [];
  filteredProducts: any[] = [];

  _filterKeyword: string = '';
  get filterKeyword(): string {
    return this._filterKeyword;
  }
  set filterKeyword(value: string){
    this._filterKeyword = value;
    this.filteredProducts = this.filterKeyword ? this.performFilter(this.filterKeyword) : this.orgProducts;
  }

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    const resolvedData: any = this.route.snapshot.data['resolvedData'];
    this.orgProducts = resolvedData['products'];
    this.filteredProducts = [...this.orgProducts];
  }

  performFilter(filterBy: string): any[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.orgProducts.filter((product: any) =>
      product.name.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

}
