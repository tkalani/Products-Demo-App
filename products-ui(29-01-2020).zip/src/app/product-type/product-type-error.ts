export class ProductTypeError {
    errorNumber: number;
    message: string;
    friendlyMessage: string;
}