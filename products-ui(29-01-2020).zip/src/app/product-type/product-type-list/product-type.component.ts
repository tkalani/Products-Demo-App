import { Component, OnInit } from '@angular/core';
import { ProductTypeService } from '../product-type.service';
import { Router } from '@angular/router';
import { ProductType } from '../product-type';

@Component({
  selector: 'app-product-type',
  templateUrl: './product-type.component.html',
  styleUrls: ['./product-type.component.css']
})
export class ProductTypeComponent implements OnInit {

  orgProductTypes: ProductType[] = [];
  filteredProductTypes: ProductType[] = [];

  _filterKeyword: string = '';
  get filterKeyword(): string {
    return this._filterKeyword;
  }
  set filterKeyword(value: string){
    this._filterKeyword = value;
    this.filteredProductTypes = this.filterKeyword ? this.performFilter(this.filterKeyword) : this.orgProductTypes;
  }

  constructor(private productTypeService: ProductTypeService,
              private router: Router) { }

  ngOnInit() {
    this.productTypeService.getProductTypes().subscribe({
      next: productTypes => { 
        this.orgProductTypes = productTypes; 
        this.filteredProductTypes = [...this.orgProductTypes];
      }
    });
  }

  addProductType(){
    this.router.navigate(['/product-types', 'add']);
  }

  deleteProductTypeById(productTypeId: number){
    this.productTypeService.deleteProductTypeById(productTypeId).subscribe({
      next: data => { this.ngOnInit(); }
    });
  }

  performFilter(filterBy: string): any[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.orgProductTypes.filter((product: any) =>
      product.name.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

}
