import { TestBed } from '@angular/core/testing';

import { ProductTypeResolverService } from './product-type-resolver.service';

describe('ProductTypeResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProductTypeResolverService = TestBed.get(ProductTypeResolverService);
    expect(service).toBeTruthy();
  });
});
