import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ProductTypeService } from './product-type.service';

@Injectable({
  providedIn: 'root'
})
export class ProductTypeResolverService implements Resolve<any> {

  constructor(private productTypeService: ProductTypeService) { }

  resolve(route: ActivatedRouteSnapshot,
          state: RouterStateSnapshot): Observable<any> {
            const type_id = route.paramMap.get('id');
            return this.productTypeService.getProductsByProductTypeID(+type_id).pipe(
              map(products => ({products: products})),
            )
          }
}
