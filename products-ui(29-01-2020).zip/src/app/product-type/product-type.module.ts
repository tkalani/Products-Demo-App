import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ProductTypeComponent } from './product-type-list/product-type.component';
import { ProductTypeDetailComponent } from './product-type-detail/product-type-detail.component';
import { ProductTypeResolverService } from './product-type-resolver.service';
import { AddProductTypeComponent } from './add-product-type/add-product-type.component';
import { EditProductTypeComponent } from './edit-product-type/edit-product-type.component';
import { ProductTypeExistGuard } from './product-type-exist.guard';
import { EditProductTypeGuard } from './edit-product-type.guard';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild([
            { path: ':id/edit', component: EditProductTypeComponent, canActivate: [ProductTypeExistGuard], canDeactivate: [EditProductTypeGuard] },
            { path: 'add', component: AddProductTypeComponent},
            { path: ':id', component: ProductTypeDetailComponent, resolve: { resolvedData: ProductTypeResolverService }, canActivate: [ProductTypeExistGuard] },
            { path: '', component: ProductTypeComponent }
        ])
    ],
    declarations: [
        ProductTypeComponent,
        ProductTypeDetailComponent,
        AddProductTypeComponent,
        EditProductTypeComponent
    ]
})
export class ProductTypeModule { }  