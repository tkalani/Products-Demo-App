import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController, TestRequest  } from '@angular/common/http/testing';

import { ProductTypeService } from './product-type.service';
import { ProductType } from './product-type';

describe('ProductTypeService Tests', () => {

  let productTypeService: ProductTypeService;
  let httpTestingController: HttpTestingController;

  let testProductTypes: ProductType[] = [
    {
        "id": 2,
        "name": "Computer"
    },
    {
        "id": 4,
        "name": "Car"
    },
    {
        "id": 1,
        "name": "Food"
    },
    {
        "id": 3,
        "name": "Mobile"
    }
]

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ ProductTypeService ]
    });
    productTypeService = TestBed.get(ProductTypeService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  it('should GET all books', () => {

    productTypeService.getProductTypes()
                      .subscribe((data: ProductType[]) => {
                        expect(data.length).toBe(4);
                      });


    let productTypesRequest: TestRequest = httpTestingController.expectOne('http://localhost:8080/api/product-types');
    expect(productTypesRequest.request.method).toEqual('GET');
    productTypesRequest.flush(testProductTypes);

    httpTestingController.verify();

    // const service: ProductTypeService = TestBed.get(ProductTypeService);
    // expect(service).toBeTruthy();
  });


});
