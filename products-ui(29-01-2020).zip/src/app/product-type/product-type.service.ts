import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { ProductType } from './product-type';
import { ProductTypeError } from './product-type-error';

@Injectable({
  providedIn: 'root'
})
export class ProductTypeService {

  private getProductTypesUrl = 'http://localhost:8080/api/product-types';
  private getProductsByProductTypeIDUrl = 'http://localhost:8080/api/product-types';
  private getProductTypeByIDUrl = 'http://localhost:8080/api/product-types';
  private createProductTypeUrl = 'http://localhost:8080/api/product-types';
  private deleteProductTypeByIdUrl = 'http://localhost:8080/api/product-types';
  private updateProductTypeUrl = 'http://localhost:8080/api/product-types';

  constructor(private http: HttpClient) { }

  getProductTypes(): Observable<ProductType[] | ProductTypeError> {
    return this.http.get<ProductType[]>(this.getProductTypesUrl).pipe(
      catchError(err => this.handleHttpError(err))
    );
  }

  getProductsByProductTypeID(id: number): Observable<any[]> {
    return this.http.get<any[]>(this.getProductsByProductTypeIDUrl+"/"+id+"/p");
  }

  createProductType(productType: ProductType): Observable<ProductType> {
    let options = { headers: new HttpHeaders({'Content-Type': 'application/json'})};
    return this.http.post<ProductType>(this.createProductTypeUrl, productType, options);
  }

  deleteProductTypeById(productTypeId: number): Observable<void> {
    return this.http.delete<void>(this.deleteProductTypeByIdUrl+"/"+productTypeId);
  }

  getProductTypeByID(productTypeId: number): Observable<ProductType>{
    return this.http.get<ProductType>(this.getProductTypeByIDUrl+"/"+productTypeId);
  }

  updateProductType(productType: ProductType): Observable<ProductType> {
    let options = { headers: new HttpHeaders({'Content-Type': 'application/json'})};
    return this.http.put<ProductType>(this.updateProductTypeUrl, productType, options);
  }

  private handleHttpError(error: HttpErrorResponse): Observable<ProductTypeError>{
    let dataError = new ProductTypeError();
    dataError.errorNumber = error.status;
    dataError.message = error.statusText;
    dataError.friendlyMessage = "An error occurred while reteving data";
    return throwError(dataError);
  }
}
