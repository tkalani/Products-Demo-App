import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { ProductType } from './product-type';

@Injectable({
  providedIn: 'root'
})
export class ProductTypeService {

  private getProductTypesUrl = 'http://localhost:8080/api/product-types';
  private getProductsByProductTypeIDUrl = 'http://localhost:8080/api/product-types';
  private getProductTypeByIDUrl = 'http://localhost:8080/api/product-types';
  private createProductTypeUrl = 'http://localhost:8080/api/product-types';
  private deleteProductTypeByIdUrl = 'http://localhost:8080/api/product-types';
  private updateProductTypeUrl = 'http://localhost:8080/api/product-types';

  constructor(private http: HttpClient) { }

  getProductTypes(): Observable<ProductType[]> {
    return this.http.get<any[]>(this.getProductTypesUrl).pipe();
  }

  getProductsByProductTypeID(id: number): Observable<any[]> {
    return this.http.get<any[]>(this.getProductsByProductTypeIDUrl+"/"+id+"/p").pipe();
  }

  createProductType(productType: ProductType): Observable<ProductType> {
    let options = { headers: new HttpHeaders({'Content-Type': 'application/json'})};
    return this.http.post<ProductType>(this.createProductTypeUrl, productType, options).pipe(
      tap( productType => {  })
    );
  }

  deleteProductTypeById(productTypeId: number): Observable<void> {
    return this.http.delete<void>(this.deleteProductTypeByIdUrl+"/"+productTypeId).pipe();
  }

  getProductTypeByID(productTypeId: number): Observable<ProductType>{
    return this.http.get<ProductType>(this.getProductTypeByIDUrl+"/"+productTypeId).pipe();
  }

  updateProductType(productType: ProductType): Observable<ProductType> {
    let options = { headers: new HttpHeaders({'Content-Type': 'application/json'})};
    return this.http.put<ProductType>(this.updateProductTypeUrl, productType, options).pipe();
  }
}
