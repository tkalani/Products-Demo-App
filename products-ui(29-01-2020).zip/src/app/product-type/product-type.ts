export interface ProductType {
    id ?: number,
    name ?: String
}