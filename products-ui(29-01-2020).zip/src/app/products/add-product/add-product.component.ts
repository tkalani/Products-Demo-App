import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { ProductTypeService } from '../../product-type/product-type.service';
import { UserService } from '../../user/user.service';
import { ProductService } from '../product.service';
import { ProductType } from '../../product-type/product-type';
import { User } from '../../user/user';
import { Product } from '../product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  addProductForm: FormGroup;
  productTypes: ProductType[] = [];
  users: User[] = [];

  constructor(private productService: ProductService,
              private productTypeService: ProductTypeService,
              private userService: UserService,
              private fb: FormBuilder,
              private router: Router) {
    this.productTypeService.getProductTypes().subscribe({
      next: productTypes => {
        this.productTypes = productTypes;
      }
    });

    this.userService.getUsers().subscribe({
      next: users => {
        this.users = users;
      }
    });
  }

  ngOnInit() {
    this.addProductForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      productType: ['', Validators.required],
      user: ['', Validators.required]
    });
  }

  saveProduct(formValues){
    let newProductType: ProductType = this.getProductTypeById(formValues.productType);
    let newProductUser: User = this.getUserById(formValues.user);
    let newProduct: Product = {
      name: formValues.name,
      productType: newProductType,
      user: newProductUser
    };
    this.productService.createProduct(newProduct).subscribe({
      next: data => { this.router.navigate(['/users']); }
    });
  }

  getProductTypeById(id: number): ProductType {
    return this.productTypes.find(type => type.id=== +id);
  }

  getUserById(id: number): User {
    return this.users.find(user => user.id=== +id);
  }

}
