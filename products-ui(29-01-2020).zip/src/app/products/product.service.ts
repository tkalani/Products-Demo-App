import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private getProductsUrl = 'http://localhost:8080/api/products';
  private getProductByIDUrl = 'http://localhost:8080/api/products';
  private createProductUrl = 'http://localhost:8080/api/products';
  private deleteProductByIdUrl = 'http://localhost:8080/api/products';

  constructor(private http: HttpClient) { }

  getProducts(): Observable<Product[]> {
    return this.http.get<any[]>(this.getProductsUrl).pipe();
  }

  getProductById(id: number): Observable<Product> {
    return this.http.get<any>(this.getProductByIDUrl+"/"+id).pipe();
  }

  createProduct(product: Product): Observable<Product> {
    let options = { headers: new HttpHeaders({'Content-Type': 'application/json'})};
    return this.http.post<Product>(this.createProductUrl, product, options);
  }

  deleteProductById(productId: number): Observable<void> {
    return this.http.delete<void>(this.deleteProductByIdUrl+"/"+productId).pipe();
  }
}
