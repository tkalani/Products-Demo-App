import { ProductType } from '../product-type/product-type';
import { User } from '../user/user';

export interface Product {
    id ?: number,
    name ?: string,
    productType ?: ProductType,
    user ?: User
}