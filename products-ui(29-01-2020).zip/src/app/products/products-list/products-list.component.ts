import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { Product } from '../product';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {
  orgProducts: Product[] = []; 
  filteredProducts: Product[] = [];
  type: boolean = false;
  sortCol: string = 'id';
  
  _filterKeyword: string = '';
  get filterKeyword(): string {
    return this._filterKeyword;
  }
  set filterKeyword(value: string){
    this._filterKeyword = value;
    this.filteredProducts = this.filterKeyword ? this.performFilter(this.filterKeyword) : this.orgProducts;
  }


  constructor(private productService: ProductService,
              private router: Router) { }

  ngOnInit() {
    this.productService.getProducts().subscribe({
      next: products => {
        this.orgProducts = products;
        this.filteredProducts = [...this.orgProducts];
        this.sortBy(this.sortCol, this.type);
      }
    });
  }

  sortBy(col: string, type: boolean){
    this.sortCol = col;
    this.type = !type;
    if(this.sortCol == 'id'){
      this.filteredProducts = this.type? this.filteredProducts.sort(sortByIdAsc) : this.filteredProducts.sort(sortByIdDsc);
    }
  }

  performFilter(filterBy: string): Product[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.orgProducts.filter((product: any) =>
      product.name.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  addProduct(){
    this.router.navigate(['/products', 'add']);
  }

  deleteProductById(productId: number){
    this.productService.deleteProductById(productId).subscribe({
      next: data => { this.ngOnInit(); }
    });
  }

}

function sortByIdAsc(s1: any, s2: any){
    return s1.id-s2.id;
}

function sortByIdDsc(s1: any, s2: any){
  return s2.id-s1.id;
}
