import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ProductsListComponent } from './products-list/products-list.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddProductComponent } from './add-product/add-product.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild([
            { path: 'add', component: AddProductComponent },
            { path: ':id', component: ProductDetailComponent },
            { path: '', component: ProductsListComponent }
        ])
    ],
    declarations: [
        ProductsListComponent,
        ProductDetailComponent,
        AddProductComponent
    ]
})
export class ProductModule { }  