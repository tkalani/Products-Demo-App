import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {

  user: User; 

  orgProducts: User[] = []; 
  filteredProducts: User[] = [];

  _filterKeyword: string = '';
  get filterKeyword(): string {
    return this._filterKeyword;
  }
  set filterKeyword(value: string){
    this._filterKeyword = value;
    this.filteredProducts = this.filterKeyword ? this.performFilter(this.filterKeyword) : this.orgProducts;
  }

  constructor(private userService: UserService,
              private route: ActivatedRoute) { }

  ngOnInit() {
    const resolvedData: any = this.route.snapshot.data['resolvedData'];
    this.orgProducts = resolvedData['products'];
    this.filteredProducts = [...this.orgProducts];
    
    this.route.paramMap.subscribe(
      data => {
        this.userService.getUserByID(+data.get('id')).subscribe({
          next: user => { this.user = user; }
        });
      }
    );
  }

  performFilter(filterBy: string): User[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.orgProducts.filter((product: any) =>
      product.name.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

}
