import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class UserExistGuard implements CanActivate {

  constructor(private userService: UserService,
              private router: Router) {

  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
      var productExists = this.userService.getUserByID(+next.params['id']);
      var subject = new Subject<boolean>();
      productExists.subscribe(
        res => {
          if (!res) {
            console.log("User doesn't exist");
            this.router.navigate(['/404']);
          }
          subject.next(!!res);
        },
        error => {
          this.router.navigate(['/404']);
          return false;
        });
      return subject.asObservable();
  }
  
}
