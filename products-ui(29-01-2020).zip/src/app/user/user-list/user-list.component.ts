import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  orgUsers: User[] = [];
  filteredUsers: User[] = [];

  _filterKeyword: string = '';
  get filterKeyword(): string {
    return this._filterKeyword;
  }
  set filterKeyword(value: string){
    this._filterKeyword = value;
    this.filteredUsers = this.filterKeyword ? this.performFilter(this.filterKeyword) : this.orgUsers;
  }

  constructor(private userService: UserService,
              private router: Router) { }

  ngOnInit() {
    this.userService.getUsers().subscribe({
      next: users => {
        this.orgUsers = users;
        this.filteredUsers = [...this.orgUsers];
      }
    });
  }

  performFilter(filterBy: string): any[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.orgUsers.filter((product: any) =>
      product.name.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  addUser(){
    this.router.navigate(['/users', 'add']);
  }

  deleteUserById(user_id: number){
    this.userService.deleteUserById(user_id).subscribe({
      next: data => { this.ngOnInit(); }
    })
  }

}
