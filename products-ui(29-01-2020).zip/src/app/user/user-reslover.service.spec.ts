import { TestBed } from '@angular/core/testing';

import { UserResloverService } from './user-reslover.service';

describe('UserResloverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserResloverService = TestBed.get(UserResloverService);
    expect(service).toBeTruthy();
  });
});
