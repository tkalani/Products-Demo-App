import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { UserService } from './user.service';
import { map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Product } from '../products/product';

@Injectable({
  providedIn: 'root'
})
export class UserResloverService implements Resolve<any> {

  constructor(private userService: UserService) { }

  resolve(route: ActivatedRouteSnapshot,
          state: RouterStateSnapshot): Observable<any> {
            const user_id = route.paramMap.get('id');
            return this.userService.getProductsByUserID(+user_id).pipe(
              map(products => ({products: products})),
            )
          }
}
