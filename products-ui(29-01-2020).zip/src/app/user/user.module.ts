import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { UserListComponent } from '../user/user-list/user-list.component';
import { UserDetailComponent } from './user-detail/user-detail.component';
import { UserResloverService } from './user-reslover.service';
import { AddUserComponent } from './add-user/add-user.component';
import { UserExistGuard } from './user-exist.guard';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild([
            { path: 'add', component: AddUserComponent },
            {path: ':id', component: UserDetailComponent, resolve: { resolvedData: UserResloverService }, canActivate: [UserExistGuard] },
           { path: '', component: UserListComponent }
        ])
    ],
    declarations: [
        UserListComponent,
        UserDetailComponent,
        AddUserComponent
    ]
})
export class UserModule { }