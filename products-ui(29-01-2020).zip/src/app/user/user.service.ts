import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';
import { Product } from '../products/product';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private getUsersUrl = 'http://localhost:8080/api/users';
  private getUserByIDUrl = 'http://localhost:8080/api/users';
  private getProductsByUserIDUrl = 'http://localhost:8080/api/users';
  private createUserUrl = 'http://localhost:8080/api/users';
  private deleteUserByIdUrl = 'http://localhost:8080/api/users';

  constructor(private http: HttpClient) { }

  getUsers(): Observable<User[]> {
    return this.http.get<any[]>(this.getUsersUrl).pipe();
  }

  getUserByID(id: number): Observable<User> {
    return this.http.get<any>(this.getUserByIDUrl+"/"+id).pipe();
  }

  getProductsByUserID(user_id: number): Observable<Product[]> {
    return this.http.get<any>(this.getProductsByUserIDUrl+"/"+user_id+"/p").pipe();
  }

  createUser(user: User): Observable<User> {
    let options = { headers: new HttpHeaders({'Content-Type': 'application/json'})};
    return this.http.post<User>(this.createUserUrl, user, options).pipe();
  }

  deleteUserById(user_id: number): Observable<void> {
    return this.http.delete<void>(this.deleteUserByIdUrl+"/"+user_id).pipe();
  }
}
